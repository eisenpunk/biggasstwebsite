import logging
import asyncio
import aiosqlite
from aiogram import Bot, Dispatcher, Router
from aiogram.types import Message, WebAppInfo
from aiogram.filters import CommandStart
from aiogram.enums import ParseMode
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.client.bot import DefaultBotProperties
from aiogram.exceptions import TelegramServerError
from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadSignature


API_TOKEN = '7173774346:AAH8m2Yb3_nRSnqOauGHFejDVYhOagORRS8'
SECRET_KEY = 'Veryverysecretkey*42@!'  # Секретный ключ для подписи токенов

# Логирование
logging.basicConfig(level=logging.INFO)

async def init_db():
    async with aiosqlite.connect('users.db') as db:
        await db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                balance INTEGER DEFAULT 250,
                referrer_id INTEGER,
                subscribed BOOLEAN DEFAULT 0,
                wallet_address TEXT,
                subscribed_twitter BOOLEAN DEFAULT 0,
                language TEXT DEFAULT 'ru'
            )
        ''')
        await db.commit()

def generate_token(user_id):
    serializer = URLSafeTimedSerializer(SECRET_KEY)
    return serializer.dumps(user_id)

def webapp_builder(user_id: int) -> InlineKeyboardBuilder:
    token = generate_token(user_id)
    builder = InlineKeyboardBuilder()
    builder.button(
        text="Let's play clicker game!",
        #web_app=WebAppInfo(url=f"https://28d4-188-163-96-14.ngrok-free.app?user_id={user_id}&token={token}")
        web_app=WebAppInfo(url=f"https://df80-188-163-96-14.ngrok-free.app/")
    )
    return builder.as_markup()


router = Router()



@router.message(CommandStart())
async def send_welcome(message: Message) -> None:
    user_id = message.from_user.id
    await message.reply('Привет! Я бот для игры в кликер')
    await message.reply(
        'CLICK! CLICK! CLICK!',
        reply_markup=webapp_builder(user_id)
    )
    





async def main() -> None:

    await init_db()
    bot = Bot(API_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)
    print('Bot started')
    try:
        await bot.delete_webhook(True)
        await dp.start_polling(bot)
    except Exception as e:
        logging.error(f"Error occurred: {e}")
    finally:
        await bot.session.close()  # Закрываем сессию бота


if __name__ == '__main__':  # pragma: no cover
    asyncio.run(main())
