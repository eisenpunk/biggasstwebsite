import flet as ft
import asyncio
import aiosqlite
from urllib.parse import urlparse, parse_qs
from itsdangerous import URLSafeTimedSerializer, BadSignature

SECRET_KEY = 'Veryverysecretkey*42@!'  # Секретный ключ для подписи токенов

async def init_db():
    async with aiosqlite.connect('users.db') as db:
        await db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                balance INTEGER DEFAULT 250,
                referrer_id INTEGER,
                subscribed BOOLEAN DEFAULT 0,
                wallet_address TEXT,
                subscribed_twitter BOOLEAN DEFAULT 0,
                language TEXT DEFAULT 'ru'
            )
        ''')
        await db.commit()


async def get_balance(user_id):
    async with aiosqlite.connect('users.db') as db:
        async with db.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,)) as cursor:
            row = await cursor.fetchone()
            if row:
                return row[0]
            else:
                await db.execute('INSERT INTO users (user_id) VALUES (?)', (user_id,))
                await db.commit()
                return 0

async def update_balance(user_id, new_balance):
    async with aiosqlite.connect('users.db') as db:
        await db.execute('UPDATE users SET balance = ? WHERE user_id = ?', (new_balance, user_id))
        await db.commit()

def verify_token(token, max_age=3600):
    serializer = URLSafeTimedSerializer(SECRET_KEY)
    try:
        user_id = serializer.loads(token, max_age=max_age)
        return user_id
    except BadSignature:
        return None



async def main(page: ft.Page):
    page.title = "Telegram Clicker Game"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = "#f8efce"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    print("Hello World2!")


    # Извлечение user_id и token из URL
    url_query = urlparse(page.url).query
    query_params = parse_qs(url_query)
    user_id = int(query_params.get('user_id', [0])[0])
    token = query_params.get('token', [''])[0]

    if verify_token(token) != user_id:
        page.add(ft.Text("Invalid or expired token.", size=30, color="red"))
        return

    await init_db()


    initial_balance = await get_balance(user_id)

    async def score_up(event: ft.ContainerTapEvent) -> None:
        score.data += 1
        score.value = str(score.data)
        
        image.scale = 0.95
        score_counter.opacity = 50
        score_counter.value = "+1🍪"
        score_counter.right = 0
        score_counter.left = tap_position[0]
        score_counter.top = tap_position[1]
        score_counter.bottom = 0

        progress_bar.value += (1/10)

        if score.data % 10 == 0:
            page.snack_bar = ft.SnackBar(
                content=ft.Text(
                    value= "🍪 +10",
                    size = 20,
                    color="#fad573",
                    text_align=ft.TextAlign.CENTER
                ),
                bgcolor="#25223a"
            )
            page.snack_bar.open=True
            progress_bar.value = 0

        await update_balance(user_id, score.data)  # Обновление счета в базе данных

        await page.update_async()
        await asyncio.sleep(0.1)
        image.scale = 1
        score_counter.opacity = 0

        await page.update_async()


    def on_tap_down(event: ft.ContainerTapEvent):
        global tap_position
        tap_position = (event.local_x, event.local_y)




    score = ft.Text(value=str(initial_balance), size=100, data=initial_balance, color="brown")
    score_counter = ft.Text(size=40, animate_opacity=ft.Animation(duration=200, curve=ft.AnimationCurve.BOUNCE_IN), color="brown")
    image = ft.Image(
        src='cookie.png',
        fit=ft.ImageFit.CONTAIN,
        animate_scale=ft.Animation(duration=600, curve=ft.AnimationCurve.EASE)
    )
    progress_bar = ft.ProgressBar(
        value=0,
        width=page.width - 200,
        bar_height=20,
        color="#ff8b71",
        bgcolor="#bf6524"
    )

    await page.add_async(
        score,
        ft.Container(
            content=ft.Stack(controls=[image, score_counter]),
            on_click=score_up,
            on_tap_down=on_tap_down,
            margin=ft.Margin(0, 0, 0, 30)
        ),
        ft.Container(
            content=progress_bar, border_radius=ft.BorderRadius(10,10,10,10))
    )




tap_position = (0, 0)
ft.app(target=main, view=None, port = 80)